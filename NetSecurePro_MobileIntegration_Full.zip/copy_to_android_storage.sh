#!/bin/bash

echo "📦 Copie des fichiers vers la mémoire Android..."

SRC_DIR="/mnt/data"
DEST_PICTURES="/storage/emulated/0/Pictures"
DEST_DOWNLOAD="/storage/emulated/0/Download"
DEST_DOCS="/storage/emulated/0/Documents"

IMG_FILE="A_flowchart-style_diagram_illustrates_the_integrat.png"
ZIP_FILE="NetSecurePro_AITerminal_KaliCLI.zip"
JSON_FILE="CLASS_CLONE_MODULE_KALI_CLI.json"

cp "$SRC_DIR/$IMG_FILE" "$DEST_PICTURES/" && echo "🖼️ Image copiée dans la Galerie"
cp "$SRC_DIR/$ZIP_FILE" "$DEST_DOWNLOAD/" && echo "📦 ZIP copié dans Téléchargements"
cp "$SRC_DIR/$JSON_FILE" "$DEST_DOCS/" && echo "🧠 JSON copié dans Documents"

echo "✅ Copie terminée."
